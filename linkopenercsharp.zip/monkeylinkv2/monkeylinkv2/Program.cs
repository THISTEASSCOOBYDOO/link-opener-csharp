﻿using System;
using System.Diagnostics;

class Program
{
    static void Main(string[] args)
    {
        // The URL you want to open
        string url = "https://www.youtube.com/watch?v=vvMMYzCxclA&t=3s";

        try
        {
            // Use the Process.Start method to open the URL
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Console.WriteLine("💔" + ex.Message);
        }
    }
}
